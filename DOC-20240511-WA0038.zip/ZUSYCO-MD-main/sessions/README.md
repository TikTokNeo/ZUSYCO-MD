English;
## Only Upload creds.json File in To This
#### If you have ZUSYCO-QR.nima File ❌ Don't Upload ❌ it in This
[`Upload ZUSYCO-QR.nima File Here`](/)
<br><br>

## මෙයට creds.json file එක පමණක් Upload කරන්න.
#### ඔයාගාව තියෙන්නේ ZUSYCO-QR.nima File එක නම් ඒක මේකට අප්ලෝඩ් කරන්න එපා !
[`ZUSYCO-QR.nima File එක මෙතන අප්ලොඩ් කරන්න`](/)
